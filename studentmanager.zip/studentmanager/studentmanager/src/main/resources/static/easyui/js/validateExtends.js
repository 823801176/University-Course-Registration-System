/**
 * Extend easyui form validation
 */

$.extend($.fn.validatebox.defaults.rules, {
    //Verifying Chinese characters
    CHS: {
        validator: function (value) {
            return /^[\u0391-\uFFE5]+$/.test(value);
        },
        message: 'Only Chinese characters can be input'
    },
    //verify the phone number
    mobile: {
        validator: function (value) {
            var reg = /^[0-9]*$/;
            return reg.test(value);
        },
        message: 'Only in numeric format'
    },
  	//Verify the number only
    number: {
        validator: function (value) {
            var reg = /^[0-9]*$/;
            return reg.test(value);
        },
        message: 'Only in numeric format'
    },
	//Verification accounts cannot be duplicated
	repeat: {
		validator: function (value) {
			var flag = true;
			$.ajax({
				type: "post",
				async: false,
				url: "SystemServlet?method=AllAccount&t="+new Date().getTime(),
				success: function(data){
					var account = $.parseJSON(data);
		            for(var i=0;i < account.length;i++){
		            	if(value == account[i]){
		            		flag = false;
		            		break;
		            	}
		            }
				}
			});
			return flag;
	    },
	    message: 'User already exists'
	},
	
	// Verify that the course cannot be repeated
	repeat_course: {
		validator: function (value) {
			var flag = true;
			$.ajax({
				type: "post",
				async: false,
				url: "CourseServlet?method=CourseList&t="+new Date().getTime(),
				success: function(data){
					var course = $.parseJSON(data);
		            for(var i=0;i < course.length;i++){
		            	if(value == course[i].name){
		            		flag = false;
		            		break;
		            	}
		            }
				}
			});
			return flag;
	    },
	    message: 'Course name already exists'
	},
	
	// Verify that grades cannot be repeated
	repeat_grade: {
		validator: function (value) {
			var flag = true;
			$.ajax({
				type: "post",
				async: false,
				url: "GradeServlet?method=GradeList&t="+new Date().getTime(),
				success: function(data){
					var grade = $.parseJSON(data);
		            for(var i=0;i < grade.length;i++){
		            	if(value == grade[i].name){
		            		flag = false;
		            		break;
		            	}
		            }
				}
			});
			return flag;
	    },
	    message: 'Grade name already exists'
	},
	
	// Verify that the class cannot be repeated
	repeat_clazz: {
		validator: function (value, param) {
			var gradeid = $(param[0]).combobox("getValue");
			var flag = true;
			$.ajax({
				type: "post",
				async: false,
				data: {gradeid: gradeid},
				url: "ClazzServlet?method=ClazzList&t="+new Date().getTime(),
				success: function(data){
					var clazz = $.parseJSON(data);
		            for(var i=0;i < clazz.length;i++){
		            	if(value == clazz[i].name){
		            		flag = false;
		            		break;
		            	}
		            }
				}
			});
			return flag;
	    },
	    message: 'A class with the same name already exists in this grade'
	},
	
	//Verify that two values are the same
	equals: {
        validator: function (value, param) {
        	if($(param[0]).val() != value){
        		return false;
        	} else{
        		return true;
        	}
            
        }, message: 'The passwords are different.'
    },
    
    //Password verification
    password: {
        validator: function (value) {
        	var reg = /^[a-zA-Z0-9]{6,16}$/;
        	return reg.test(value);
            
        }, message: 'The password is 6-16 digits and can only be in English and numbers'
    },
    
    //Verify that the old password is correct
    oldPassword: {
        validator: function (value, param) {
        	if(param != value){
        		return false;
        	} else{
        		return true;
        	}
            
        }, message: 'Incorrect password'
    },
    
    //Verify zip code
    zipcode: {
        validator: function (value) {
            var reg = /^[1-9]\d{5}$/;
            return reg.test(value);
        },
        message: 'Postal code must be 6 digits starting from non-zero.'
    },
    //User account verification (_alphanumeric only)
    account: {//param的值为[]中值
        validator: function (value, param) {
            if (value.length < param[0] || value.length > param[1]) {
                $.fn.validatebox.defaults.rules.account.message = 'User name length must be in the range ' + param[0] + 'to' + param[1] + '';
                return false;
            } else {
                if (!/^[\w]+$/.test(value)) {
                    $.fn.validatebox.defaults.rules.account.message = 'The user name can only be composed of numbers, letters and underscores.';
                    return false;
                } else {
                    return true;
                }
            }
        }, message: ''
    }
}) 
