package com.wdd.studentmanager.controller;

import com.wdd.studentmanager.domain.Course;
import com.wdd.studentmanager.domain.SelectedCourse;
import com.wdd.studentmanager.domain.Student;
import com.wdd.studentmanager.domain.Teacher;
import com.wdd.studentmanager.service.CourseService;
import com.wdd.studentmanager.service.SelectedCourseService;
import com.wdd.studentmanager.util.AjaxResult;
import com.wdd.studentmanager.util.Const;
import com.wdd.studentmanager.util.PageBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Classname SelectedCourseController
 * @Description selectedCourseController
 */
@Controller
@RequestMapping("/selectedCourse")
public class SelectedCourseController {

    @Autowired
    private SelectedCourseService selectedCourseService;

    @Autowired
    private CourseService courseService;

    @GetMapping("/selectedCourse_list")
    public String selectedCourseList(){
        return "course/selectedCourseList";
    }

    /**
     * Load the list of course selection information
     * @param page
     * @param rows
     * @param studentid
     * @param courseid
     * @param from
     * @return
     */
    @PostMapping("/getSelectedCourseList")
    @ResponseBody
    public Object getClazzList(@RequestParam(value = "page", defaultValue = "1")Integer page,
                               @RequestParam(value = "rows", defaultValue = "100")Integer rows,
                               @RequestParam(value = "studentid", defaultValue = "0")String studentid,
                               @RequestParam(value = "courseid", defaultValue = "0")String courseid ,String from,HttpSession session){
        Map<String,Object> paramMap = new HashMap();
        paramMap.put("pageno",page);
        paramMap.put("pagesize",rows);
        if(!studentid.equals("0"))  paramMap.put("studentId",studentid);
        if(!courseid.equals("0"))  paramMap.put("courseId",courseid);
        // determine whether the user is a student or a teacher
        Student student = (Student) session.getAttribute(Const.STUDENT);
        if(!StringUtils.isEmpty(student)){
            // student permissions, only query the course selection information of the student
            paramMap.put("studentid",student.getId());
        }
        Teacher teacher = (Teacher) session.getAttribute(Const.TEACHER);
        if(!StringUtils.isEmpty(teacher)){
            // teacher permissions, only query the course selection information of the teacher
            paramMap.put("teacherid",teacher.getId());
        }
        PageBean<SelectedCourse> pageBean = selectedCourseService.queryPage(paramMap);
        if(!StringUtils.isEmpty(from) && from.equals("combox")){
            return pageBean.getDatas();
        }else{
            Map<String,Object> result = new HashMap();
            result.put("total",pageBean.getTotalsize());
            result.put("rows",pageBean.getDatas());
            return result;
        }
    }

    /**
     * student select course
     * @param selectedCourse
     * @return
     */
    @PostMapping("/addSelectedCourse")
    @ResponseBody
    public AjaxResult addSelectedCourse(SelectedCourse selectedCourse){
        AjaxResult ajaxResult = new AjaxResult();
        try {
            int count = selectedCourseService.addSelectedCourse(selectedCourse);
            if(count == 1){
                ajaxResult.setSuccess(true);
                ajaxResult.setMessage("success");
            }else if(count == 0){
                ajaxResult.setSuccess(false);
                ajaxResult.setMessage("The number of elective students is full");
            }else if(count == 2){
                ajaxResult.setSuccess(false);
                ajaxResult.setMessage("This course has been selected");
            }
        }catch (Exception e){
            e.printStackTrace();
            ajaxResult.setSuccess(false);
            ajaxResult.setMessage("System internal error, please contact the administrator!");
        }
        return ajaxResult;
    }


    /**
     * Drop the course
     * @param id
     * @return
     */
    @PostMapping("/deleteSelectedCourse")
    @ResponseBody
    public AjaxResult deleteSelectedCourse(Integer id){
        AjaxResult ajaxResult = new AjaxResult();

        try {
            int count = selectedCourseService.deleteSelectedCourse(id);
            System.out.println("count-->");
            System.out.println(count);
            if(count > 0){
                ajaxResult.setSuccess(true);
                ajaxResult.setMessage("success");
            }else{
                ajaxResult.setSuccess(false);
                ajaxResult.setMessage("not found");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ajaxResult;
    }
    /**
     * The course selected by the student is queried by the course id in the course selection information
     * @param studentid
     * @param session
     * @return
     */
    @RequestMapping("/getStudentSelectedCourseList")
    @ResponseBody
    public Object getStudentSelectedCourseList(@RequestParam(value = "studentid", defaultValue = "0")String studentid , HttpSession session){

        Map<Object,Object> paramMap = new HashMap();
        Teacher teacher = (Teacher) session.getAttribute(Const.TEACHER);
        if(!StringUtils.isEmpty(teacher)){
            // teacher permissions, only query the course selection information of the teacher
            paramMap.put("teacherid",teacher.getId());
        }

        // Query course selection information by student id
        List<SelectedCourse> selectedCourseList = selectedCourseService.getAllBySid(Integer.parseInt(studentid));
        // The course selected by the student is queried by the course id in the course selection information
        List<Integer> ids = new ArrayList<>();
        for(SelectedCourse selectedCourse : selectedCourseList){
            ids.add(selectedCourse.getCourseId());
        }

        paramMap.put("ids",ids);

        System.out.println(ids.toString());
        System.out.println("--------------");
        System.out.println(paramMap.get("ids").toString());

        List<Course> courseList = courseService.getCourseById(paramMap);
        return courseList;
    }


}
