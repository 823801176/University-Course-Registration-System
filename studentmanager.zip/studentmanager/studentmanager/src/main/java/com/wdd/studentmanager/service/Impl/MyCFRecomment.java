package com.wdd.studentmanager.service.Impl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wdd.studentmanager.domain.Course;
import com.wdd.studentmanager.domain.Student;
import com.wdd.studentmanager.domain.CourtsGoal;
import com.wdd.studentmanager.service.CourseService;
import com.wdd.studentmanager.service.ElectiveService;
import com.wdd.studentmanager.service.RecommendCourseService;
import com.wdd.studentmanager.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class MyCFRecomment {
	//get student id
	@Autowired
	private StudentService studentService;

	//get course id
	@Autowired
	private CourseService courseService;

	//get elective
	@Autowired
	private ElectiveService electiveService;

	@Autowired
	private RecommendCourseService recommendService;





	public void recommend() {
		//Get all students
		System.out.println("Number of all students");
		List<Student> selectAllStudent = studentService.selectAllStudent();

		System.out.println(selectAllStudent.size());
        //Get all courses
        //Depends on student id and course id to get the score
		if(selectAllStudent.size()!=0) {
			Map<Integer,List<CourtsGoal>> goalMap = new HashMap<Integer, List<CourtsGoal>>();
			List<Integer> stuList = new ArrayList<Integer>();
			List<Course> selectAllCourse = (List<Course>) courseService.selectAllCourse();
			System.out.println(" Number of all courses");
			System.out.println(selectAllCourse.size());
			for(Student stu:selectAllStudent) {

				List<CourtsGoal> courtsGoals = new ArrayList<CourtsGoal>();
				for(Course cou:selectAllCourse) {
					CourtsGoal courtsGoal = new CourtsGoal();
					Integer goal = electiveService.selectByStuAndCourseId(stu.getId(),cou.getId());
					courtsGoal.setCourseId(cou.getId());
					courtsGoal.setGoal(goal);
					courtsGoals.add(courtsGoal);
				}
                //get the relationship between student and score
				goalMap.put(stu.getId(), courtsGoals);
				stuList.add(stu.getId());
			}
			System.out.println(goalMap);
			//System.out.println(selectAllCourse);
			//Calculate user similarity
			Map<Integer,List<List<Object>>> dataMap = calcUserSimilarity(stuList.toArray(),goalMap);
			//Calculate the recommenation of courses
			Map<Integer, List<Object>> recommendCourse = calcRecommendCourse(dataMap,goalMap);
			//Process the list of recommended courses
			Map<Integer, List<Object>> handleRecommendCourse = handleRecommendCourse(recommendCourse,goalMap);
			//Delete all recommended list information
			//delectAllRecommendCourse();


			//Save the recommended list information
			//saveRecommendCourse(handleRecommendCourse);

			//delete repeat recommend course
			//repeatRecomendCourse();
		}else {
            System.out.println("none-recommend");
		}

	}


	private static Map<Integer, List<Object>> handleRecommendCourse(Map<Integer, List<Object>> recommendCourse,Map<Integer,List<CourtsGoal>> goalMap) {
		Map<Integer, List<Object>> handleRecommendCourse = new HashMap<Integer, List<Object>>();

		for(Map.Entry<Integer,List<Object>> reco:recommendCourse.entrySet()) {
			//Get the recommended course
			List<Object> re_l = reco.getValue();
			List<Object> handleCourse = new ArrayList<Object>();
			for(Object obj:re_l) {
				List<CourtsGoal> list = goalMap.get(reco.getKey());
				for(CourtsGoal c_goal:list) {
					if(Integer.parseInt(obj.toString())==c_goal.getCourseId()) {
						if(c_goal.getGoal()==0) {
							handleCourse.add(c_goal.getCourseId());
						}
					}
				}
			}
			handleRecommendCourse.put(reco.getKey(), handleCourse);
		}
		System.out.println("Final list"+handleRecommendCourse);
		return handleRecommendCourse;
	}
	/*
     * Calculate similarity of students
     * Return the top 2 similar students
	 */
	public static Map<Integer,List<List<Object>>> calcUserSimilarity(Object[] stuArr_p,Map<Integer,List<CourtsGoal>> goalMap_p) {
		//similarityUsers=new ArrayList();
        //get the similarity between target user and other users
        //Similarity user set
	    Map<Integer,List<List<Object>>> dataMap = new HashMap<Integer, List<List<Object>>>();
		for(Object stu:stuArr_p) {
            //get 2 similar users
			List<List<Object>> similarityUsers= new ArrayList();
			List<List<Object>> userSimilaritys=new ArrayList<List<Object>>();
			//Iterate over goalMap_p
			for(Map.Entry<Integer,List<CourtsGoal>> goal:goalMap_p.entrySet()) {
                //If student is the same, skip
				if(stu.toString().equals(goal.getKey().toString())) {
					continue;
				}
				List<Object> userSimilarity=new ArrayList<Object>();
                //record the student id
	            userSimilarity.add(goal.getKey());
	            userSimilarity.add(calcTwoUserSimilarity(goal.getValue(),goalMap_p.get((Integer)stu)));
	            userSimilaritys.add(userSimilarity);
			}
			sortCollection(userSimilaritys);

			System.out.println("The simularity with"+stu+"is: "+userSimilaritys);
			similarityUsers.add(userSimilaritys.get(0));
		    similarityUsers.add(userSimilaritys.get(1));
		    dataMap.put((Integer)stu, similarityUsers);
		}
		System.out.println(dataMap);
		//Show the similarity of target users and other 2 users
		return dataMap;
	}

	 /**
     * Get course list, calculate the recommended course
     */
    private static Map<Integer,List<Object>> calcRecommendCourse(Map<Integer,List<List<Object>>> dataMap,Map<Integer,List<CourtsGoal>> goalMap){
    	Map<Integer,List<List<Object>>> cf_map =  new HashMap<Integer, List<List<Object>>>();
    	//Store the total recommended score for no course
    	Map<Integer,Double> cf_sumRate =  new HashMap<Integer, Double>();
    	//Go through the dataMap and pick up the courses recommended by different students
    	for(Map.Entry<Integer,List<List<Object>>> data:dataMap.entrySet()) {
    		double recommdRate=0,sumRate=0;
    		//Get first similar user's value
    		double xs_1 = Double.parseDouble(data.getValue().get(0).get(1).toString());
    		//Get second similar user's value
    		double xs_2 = Double.parseDouble(data.getValue().get(1).get(1).toString());
    		List<CourtsGoal> list_1 = goalMap.get(data.getValue().get(0).get(0));
    		List<CourtsGoal> list_2 = goalMap.get(data.getValue().get(1).get(0));
    		if(list_1.size()==list_2.size()) {
    			List<List<Object>> recommendCourts = new ArrayList<List<Object>>();
    			for(int i=0;i<list_1.size();i++) {
    				List<Object>  recommendCourt=new ArrayList();
    				recommdRate = list_1.get(i).getGoal() * xs_1 + list_2.get(i).getGoal() * xs_2;
    				//Add course
    				recommendCourt.add(list_1.get(i).getCourseId());
    				//Add recommended score
    				recommendCourt.add(recommdRate);
    				recommendCourts.add(recommendCourt);
    				sumRate+=recommdRate;
    			}
    			cf_map.put(data.getKey(), recommendCourts);
    			cf_sumRate.put(data.getKey(), sumRate);
    		}
    	}
    	System.err.println(cf_map);
    	System.out.println(cf_sumRate);
    	//The current collection holds the collection of courses recommended for key
    	Map<Integer,List<Object>> target_map = new HashMap<Integer, List<Object>>();
    	for(Map.Entry<Integer,List<List<Object>>> cf_d:cf_map.entrySet()) {
    		List<Object> targetRecommendCourts = new ArrayList<Object>();
    		for(List<Object> obj:cf_d.getValue()) {
    			if(Double.parseDouble(obj.get(1).toString()) > cf_sumRate.get(cf_d.getKey())/cf_d.getValue().size()){ //Items with higher than average recommendation are likely to be recommended
                    targetRecommendCourts.add(obj.get(0));
                }
    		}
    		target_map.put(cf_d.getKey(), targetRecommendCourts);
    	}
    	System.out.println("Final："+target_map);
    	return target_map;
    }

	/**
     * Calculate user similarity (Euclidean distance) based on user data
     * @param user1Stars Other users rate the score
     * @param user2Starts  Current user rating score
     * @return
     */
    private static double calcTwoUserSimilarity(List<CourtsGoal> user1Stars,List<CourtsGoal> user2Starts){
        float sum=0;
        for(int i=0;i<user1Stars.size();i++){
            sum+=Math.pow(user1Stars.get(i).getGoal()-user2Starts.get(i).getGoal(),2);//平方
        }
        return Math.sqrt(sum);//sqrt
    }

    /**
     * Sorting of sets
     * @param list
     */
    private static void sortCollection(List<List<Object>> list){
        Collections.sort(list, new Comparator<List<Object>>() {
            @Override
            public int compare(List<Object> o1, List<Object> o2) {
                if(Double.valueOf(o1.get(1).toString()) > Double.valueOf(o2.get(1).toString())){
                    return 1;
                }else if(Double.valueOf(o1.get(1).toString()) < Double.valueOf(o2.get(1).toString())){
                    return -1;
                }else{
                    return 0;
                }
            }
        });
    }

}
