package com.wdd.studentmanager.service.Impl;

import com.wdd.studentmanager.mapper.ElectiveMapper;
import com.wdd.studentmanager.service.ElectiveService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Classname ElectiveServiceImpl
 * @Description None
 */
@Service
public class ElectiveServiceImpl implements ElectiveService {

    @Autowired
    private ElectiveMapper electiveMapper;

    @Override
    public Integer selectByStuAndCourseId(int studentid, int courseid) {

        return electiveMapper.selectByStuAndCourseId(studentid,courseid);
    }

    @Override
    public Integer selectByStu(int studentid) {

        return electiveMapper.selectByStu(studentid);
    }
}
