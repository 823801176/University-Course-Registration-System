package com.wdd.studentmanager.mapper;

/**
 * @Classname GradeMapper
 * @Description None
 */
public interface GradeMapper {
}
