package com.wdd.studentmanager.domain;

/**
 * @Classname Course
 * @Description None
 */
public class Course {
    private int id;
    private String name;
    private int teacherId;


    private String courseDate;
    private int selectedNum = 0;//Number of selected students
    private int maxNum = 50;//Maximum number of students
    private String info;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }

    public String getCourseDate() {
        return courseDate;
    }

    public void setCourseDate(String courseDate) {
        this.courseDate = courseDate;
    }

    public int getSelectedNum() {
        return selectedNum;
    }

    public void setSelectedNum(int selectedNum) {
        this.selectedNum = selectedNum;
    }

    public int getMaxNum() {
        return maxNum;
    }

    public void setMaxNum(int maxNum) {
        this.maxNum = maxNum;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    @Override
    public String toString() {
        return "Course{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", teacherId=" + teacherId +
                ", courseDate='" + courseDate + '\'' +
                ", selectedNum=" + selectedNum +
                ", maxNum=" + maxNum +
                ", info='" + info + '\'' +
                '}';
    }

}
