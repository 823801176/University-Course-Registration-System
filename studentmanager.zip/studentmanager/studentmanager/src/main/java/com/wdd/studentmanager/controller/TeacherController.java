package com.wdd.studentmanager.controller;

import com.wdd.studentmanager.domain.Teacher;
import com.wdd.studentmanager.service.TeacherService;
import com.wdd.studentmanager.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * @Classname TeacherController
 * @Description None
 */
@Controller
@RequestMapping("/teacher")
public class TeacherController {

    @Autowired
    private TeacherService teacherService;


    @RequestMapping("/teacher_list")
    public String teacherList(){
        return "/teacher/teacherList";
    }

    /**
     * Load the list of teacher information
     * @param page
     * @param rows
     * @param teacherName
     * @param clazzid
     * @param from
     * @param session
     * @return
     */
    @PostMapping("/getTeacherList")
    @ResponseBody
    public Object getTeacherList(@RequestParam(value = "page", defaultValue = "1")Integer page,
                                 @RequestParam(value = "rows", defaultValue = "100")Integer rows,
                                 String teacherName,
                                 @RequestParam(value = "clazzid", defaultValue = "0")String clazzid, String from, HttpSession session){
        Map<String,Object> paramMap = new HashMap();
        paramMap.put("pageno",page);
        paramMap.put("pagesize",rows);
        if(!StringUtils.isEmpty(teacherName))  paramMap.put("username",teacherName);
        if(!clazzid.equals("0"))  paramMap.put("clazzid",clazzid);

        // determine whether the user is a teacher
        Teacher teacher = (Teacher) session.getAttribute(Const.TEACHER);
        if(!StringUtils.isEmpty(teacher)){
            // If the user is a teacher, only query the information of the teacher
            paramMap.put("teacherid",teacher.getId());
        }

        PageBean<Teacher> pageBean = teacherService.queryPage(paramMap);
        if(!StringUtils.isEmpty(from) && from.equals("combox")){
            return pageBean.getDatas();
        }else{
            Map<String,Object> result = new HashMap();
            result.put("total",pageBean.getTotalsize());
            result.put("rows",pageBean.getDatas());
            return result;
        }
    }

    /**
     * delete teacher
     * @param data
     * @return
     */
    @PostMapping("/deleteTeacher")
    @ResponseBody
    public AjaxResult deleteTeacher(Data data){
        AjaxResult ajaxResult = new AjaxResult();
        try {
            File fileDir = UploadUtil.getImgDirFile();
            for(Integer id : data.getIds()){
                Teacher byId = teacherService.findById(id);
                if(!byId.getPhoto().isEmpty()){
                    File file = new File(fileDir.getAbsolutePath() + File.separator + byId.getPhoto());
                    if(file != null){
                        file.delete();
                    }
                }
            }
            int count = teacherService.deleteTeacher(data.getIds());
            if(count > 0){
                ajaxResult.setSuccess(true);
                ajaxResult.setMessage("success");
            }else{
                ajaxResult.setSuccess(false);
                ajaxResult.setMessage("fail");
            }
        }catch (Exception e){
            e.printStackTrace();
            ajaxResult.setSuccess(false);
            ajaxResult.setMessage("fail");
        }
        return ajaxResult;
    }

    /**
     * add teacher
     * @param files
     * @param teacher
     * @return
     * @throws IOException
     */
    @RequestMapping("/addTeacher")
    @ResponseBody
    public AjaxResult addTeacher(@RequestParam("file") MultipartFile[] files, Teacher teacher) throws IOException {

        AjaxResult ajaxResult = new AjaxResult();
        teacher.setSn(SnGenerateUtil.generateTeacherSn(teacher.getClazzId()));

        // upload photo
        File fileDir = UploadUtil.getImgDirFile();
        for(MultipartFile fileImg : files){

            // get the original file name
            String extName = fileImg.getOriginalFilename().substring(fileImg.getOriginalFilename().lastIndexOf("."));
            String uuidName = UUID.randomUUID().toString();

            try {
                // Building a real file path
                File newFile = new File(fileDir.getAbsolutePath() + File.separator +uuidName+ extName);

                // Upload the file to absolute path
                fileImg.transferTo(newFile);

            } catch (IOException e) {
                e.printStackTrace();
            }
            teacher.setPhoto(uuidName+extName);
        }
        // Save teacher information to database
        try{
            int count = teacherService.addTeacher(teacher);
            if(count > 0){
                ajaxResult.setSuccess(true);
                ajaxResult.setMessage("success");
            }else{
                ajaxResult.setSuccess(false);
                ajaxResult.setMessage("fail");
            }
        }catch (Exception e){
            e.printStackTrace();
            ajaxResult.setSuccess(false);
            ajaxResult.setMessage("fail");
        }

        ajaxResult.setSuccess(true);
        return ajaxResult;
    }

    @PostMapping("/editTeacher")
    @ResponseBody
    public AjaxResult editTeacher(@RequestParam("file") MultipartFile[] files,Teacher teacher){
        AjaxResult ajaxResult = new AjaxResult();

        File fileDir = UploadUtil.getImgDirFile();
        for(MultipartFile fileImg : files){

            String name = fileImg.getOriginalFilename();
            if(name.equals("")){
                break;
            }

            // get the original file name
            String extName = fileImg.getOriginalFilename().substring(fileImg.getOriginalFilename().lastIndexOf("."));
            String uuidName = UUID.randomUUID().toString();

            try {
                // Building a real file path
                File newFile = new File(fileDir.getAbsolutePath() + File.separator +uuidName+ extName);
                // Upload the file to absolute path
                fileImg.transferTo(newFile);

                Teacher byId = teacherService.findById(teacher.getId());
                File file = new File(fileDir.getAbsolutePath() + File.separator + byId.getPhoto());
                if(file != null){
                    file.delete();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            teacher.setPhoto(uuidName+extName);
        }

        try{
            int count = teacherService.editTeacher(teacher);
            if(count > 0){
                ajaxResult.setSuccess(true);
                ajaxResult.setMessage("success");
            }else{
                ajaxResult.setSuccess(false);
                ajaxResult.setMessage("fail");
            }
        }catch(Exception e){
            e.printStackTrace();
            ajaxResult.setSuccess(false);
            ajaxResult.setMessage("fail");
        }
        return ajaxResult;
    }
}
