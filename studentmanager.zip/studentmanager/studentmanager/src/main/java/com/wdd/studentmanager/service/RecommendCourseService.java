package com.wdd.studentmanager.service;

import com.wdd.studentmanager.domain.SelectedCourse;
import com.wdd.studentmanager.service.Impl.MyCFRecomment;
import com.wdd.studentmanager.util.PageBean;

import java.util.List;
import java.util.Map;

/**
 * @Classname RecommendCourseService
 * @Description None
 */
public interface RecommendCourseService {
    public void startRecommend();
}
