package com.wdd.studentmanager.service;

import com.wdd.studentmanager.domain.SelectedCourse;
import com.wdd.studentmanager.util.PageBean;

import java.util.List;
import java.util.Map;

/**
 * @Classname ElectiveService
 * @Description None
 */
public interface ElectiveService {

    Integer selectByStuAndCourseId(int studentid,int courseid);
    Integer selectByStu(int studentid);
}
