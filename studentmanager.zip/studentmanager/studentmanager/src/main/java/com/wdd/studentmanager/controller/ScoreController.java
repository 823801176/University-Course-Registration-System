package com.wdd.studentmanager.controller;

import com.wdd.studentmanager.domain.Score;
import com.wdd.studentmanager.domain.ScoreStats;
import com.wdd.studentmanager.domain.Student;
import com.wdd.studentmanager.domain.Teacher;
import com.wdd.studentmanager.service.CourseService;
import com.wdd.studentmanager.service.ScoreService;
import com.wdd.studentmanager.service.SelectedCourseService;
import com.wdd.studentmanager.service.StudentService;
import com.wdd.studentmanager.util.AjaxResult;
import com.wdd.studentmanager.util.Const;
import com.wdd.studentmanager.util.PageBean;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Classname ScoreController
 * @Description ScoreController
 */
@Controller
@RequestMapping("/score")
public class ScoreController {

    @Autowired
    private ScoreService scoreService;
    @Autowired
    private StudentService studentService;
    @Autowired
    private CourseService courseService;
    @Autowired
    private SelectedCourseService selectedCourseService;


    @GetMapping("/score_list")
    public String scoreList(){
        return "/score/scoreList";
    }


    /**
     * Load the list of grade data asynchronously
     * @param page
     * @param rows
     * @param studentid
     * @param courseid
     * @param from
     * @param session
     * @return
     */
    @RequestMapping("/getScoreList")
    @ResponseBody
    public Object getScoreList(@RequestParam(value = "page", defaultValue = "1")Integer page,
                                    @RequestParam(value = "rows", defaultValue = "100")Integer rows,
                                    @RequestParam(value = "studentid", defaultValue = "0")String studentid,
                                    @RequestParam(value = "courseid", defaultValue = "0")String courseid,
                                    String from, HttpSession session){
        Map<String,Object> paramMap = new HashMap();
        paramMap.put("pageno",page);
        paramMap.put("pagesize",rows);
        if(!studentid.equals("0"))  paramMap.put("studentid",studentid);
        if(!courseid.equals("0"))  paramMap.put("courseid",courseid);

        //Determine whether it is teacher or student authority
        Student student = (Student) session.getAttribute(Const.STUDENT);
        if(!StringUtils.isEmpty(student)){
            //Students can only query their own information
            paramMap.put("studentid",student.getId());
        }
        Teacher teacher = (Teacher) session.getAttribute(Const.TEACHER);
        if(!StringUtils.isEmpty(teacher)){
            //It is the authority of the teacher, who can only manage the grades of the courses he teaches
            paramMap.put("teacherid",teacher.getId());
        }
        PageBean<Score> pageBean = scoreService.queryPage(paramMap);
        if(!StringUtils.isEmpty(from) && from.equals("combox")){
            return pageBean.getDatas();
        }else{
            Map<String,Object> result = new HashMap();
            result.put("total",pageBean.getTotalsize());
            result.put("rows",pageBean.getDatas());
            return result;
        }
    }


    /**
     * add grade
     * @param score
     * @return
     */
    @PostMapping("/addScore")
    @ResponseBody
    public AjaxResult addScore(Score score){
        AjaxResult ajaxResult = new AjaxResult();
        //Determine whether the score has been entered
        if(scoreService.isScore(score)){
            //true means signed in
            ajaxResult.setSuccess(false);
            ajaxResult.setMessage("It has been entered, please do not enter again!");
        }else{
            int count = scoreService.addScore(score);
            if(count > 0){
                //Sign in successfully
                ajaxResult.setSuccess(true);
                ajaxResult.setMessage("Successfully entered");
            }else{
                ajaxResult.setSuccess(false);
                ajaxResult.setMessage("System error, please re-enter");
            }
        }
        return ajaxResult;
    }


    /**
     * edit grade
     * @param score
     * @return
     */
    @PostMapping("/editScore")
    @ResponseBody
    public AjaxResult editScore(Score score){
        AjaxResult ajaxResult = new AjaxResult();
        try {
            int count = scoreService.editScore(score);
            if(count > 0){
                ajaxResult.setSuccess(true);
                ajaxResult.setMessage("success");
            }else{
                ajaxResult.setSuccess(false);
                ajaxResult.setMessage("System error, please modify again");
            }
        } catch (Exception e) {
            e.printStackTrace();
            ajaxResult.setSuccess(false);
            ajaxResult.setMessage("System error, please modify again");
        }
        return ajaxResult;
    }

    /**
     * delete grade
     * @param id
     * @return
     */
    @PostMapping("/deleteScore")
    @ResponseBody
    public AjaxResult deleteScore(Integer id){
        AjaxResult ajaxResult = new AjaxResult();
        try {
            int count = scoreService.deleteScore(id);
            if(count > 0){
                ajaxResult.setSuccess(true);
                ajaxResult.setMessage("success");
            }else{
                ajaxResult.setSuccess(false);
                ajaxResult.setMessage("System error, please delete again");
            }
        } catch (Exception e) {
            e.printStackTrace();
            ajaxResult.setSuccess(false);
            ajaxResult.setMessage("System error, please delete again");
        }
        return ajaxResult;
    }

    /**
     * Import the xlsx table and save it to the database
     * @param importScore
     * @param response
     */
    @PostMapping("/importScore")
    @ResponseBody
    public void importScore(@RequestParam("importScore") MultipartFile importScore, HttpServletResponse response){
        response.setCharacterEncoding("UTF-8");
        try {
            InputStream inputStream = importScore.getInputStream();
            XSSFWorkbook xssfWorkbook = new XSSFWorkbook(inputStream);
            XSSFSheet sheetAt = xssfWorkbook.getSheetAt(0);
            int count = 0;
            String errorMsg = "";
            for(int rowNum = 1; rowNum <= sheetAt.getLastRowNum(); rowNum++){
                XSSFRow row = sheetAt.getRow(rowNum); // Get the rowNum row
                //Column 0
                XSSFCell cell = row.getCell(0); // Get column 0 of row rowNum, which is the coordinate (rowNum, 0).
                if(cell == null){
                    errorMsg += "Line" + rowNum + "Student Missing！\n";
                    continue;
                }
                //Column 1
                cell = row.getCell(1);
                if(cell == null){
                    errorMsg += "Line" + rowNum + "Course Missing！\n";
                    continue;
                }
                //Column 2
                cell = row.getCell(2);
                if(cell == null){
                    errorMsg += "Line" + rowNum + "Score Missing！\n";
                    continue;
                }
                double scoreValue = cell.getNumericCellValue();
                //Column 3
                cell = row.getCell(3);
                String remark = null;
                if(cell != null){
                    remark = cell.getStringCellValue();
                }

                //Convert students and courses into ids and store them in the database
                // First get the corresponding id
                int studentId = studentService.findByName(row.getCell(0).getStringCellValue());
                int courseId = courseService.findByName(row.getCell(1).getStringCellValue());
                // Check if it is already in the database
                Score score = new Score();
                score.setStudentId(studentId);
                score.setCourseId(courseId);
                score.setScore(scoreValue);
                score.setRemark(remark);
                if(!scoreService.isScore(score)){
                    // Save to the database
                    int i = scoreService.addScore(score);
                    if(i > 0){
                        count ++ ;
                    }
                }else{
                    errorMsg += "Line" + rowNum + "row has been entered, no more entries!\n";
                }
            }
            errorMsg += "entry successfully" + count + "！";
            response.getWriter().write("<div id='message'>"+errorMsg+"</div>");

        } catch (IOException e) {
            e.printStackTrace();
            try {
                response.getWriter().write("<div id='message'>Upload error</div>");
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

    }


    /**
     * Export the xlsx table
     * @param response
     * @param score
     * @param session
     */
    @RequestMapping("/exportScore")
    @ResponseBody
    private void exportScore(HttpServletResponse response,Score score,HttpSession session) {
        //Gets the current logged-in user type
        Student student = (Student) session.getAttribute(Const.STUDENT);
        if(!StringUtils.isEmpty(student)){
            //If you are a student, you can only view your own information
            score.setStudentId(student.getId());
        }
        try {
            response.setHeader("Content-Disposition", "attachment;filename="+ URLEncoder.encode("score_list_sid_"+score.getStudentId()+"_cid_"+score.getStudentId()+".xls", "UTF-8"));
            response.setHeader("Connection", "close");
            response.setHeader("Content-Type", "application/octet-stream");
            ServletOutputStream outputStream = response.getOutputStream();
            List<Score> scoreList = scoreService.getAll(score);
            XSSFWorkbook xssfWorkbook = new XSSFWorkbook();
            XSSFSheet createSheet = xssfWorkbook.createSheet("Score List");
            XSSFRow createRow = createSheet.createRow(0);
            createRow.createCell(0).setCellValue("student");
            createRow.createCell(1).setCellValue("course");
            createRow.createCell(2).setCellValue("score");
            createRow.createCell(3).setCellValue("remarks");
            //Implement loading data into excel files
            int row = 1;
            for( Score s:scoreList){
                createRow = createSheet.createRow(row++);
                createRow.createCell(0).setCellValue(s.getStudentName());
                createRow.createCell(1).setCellValue(s.getCourseName());
                createRow.createCell(2).setCellValue(s.getScore());
                createRow.createCell(3).setCellValue(s.getRemark());
            }
            xssfWorkbook.write(outputStream);
            outputStream.flush();
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * Go to the statistics page
     * @return
     */
    @RequestMapping("/scoreStats")
    public String scoreStats(){
        return "/score/scoreStats";
    }


    /**
     * Statistical performance data
     * @param courseid
     * @param searchType
     * @return
     */
    @RequestMapping("/getScoreStatsList")
    @ResponseBody
    public Object getScoreStatsList(@RequestParam(value = "courseid", defaultValue = "0")Integer courseid,
                                        String searchType){
        AjaxResult ajaxResult = new AjaxResult();
        if(searchType.equals("avg")){
            ScoreStats scoreStats = scoreService.getAvgStats(courseid);

            List<Double> scoreList = new ArrayList<Double>();
            scoreList.add(scoreStats.getMax_score());
            scoreList.add(scoreStats.getMin_score());
            scoreList.add(scoreStats.getAvg_score());

            List<String> avgStringList = new ArrayList<String>();
            avgStringList.add("Highest");
            avgStringList.add("Minimum");
            avgStringList.add("average");

            Map<String, Object> retMap = new HashMap<String, Object>();
            retMap.put("courseName", scoreStats.getCourseName());
            retMap.put("scoreList", scoreList);
            retMap.put("avgList", avgStringList);
            retMap.put("type", "success");

            return retMap;
        }

        Score score = new Score();
        score.setCourseId(courseid);
        List<Score> scoreList = scoreService.getAll(score);


        List<Integer> numberList = new ArrayList<Integer>();
        numberList.add(0);
        numberList.add(0);
        numberList.add(0);
        numberList.add(0);
        numberList.add(0);

        List<String> rangeStringList = new ArrayList<String>();
        rangeStringList.add("Below 60");
        rangeStringList.add("60~70");
        rangeStringList.add("70~80");
        rangeStringList.add("80~90");
        rangeStringList.add("90~100");

        String courseName = "";

        for(Score sc : scoreList){
            courseName = sc.getCourseName();  //get course name
            double scoreValue = sc.getScore();//get score
            if(scoreValue < 60){
                numberList.set(0, numberList.get(0)+1);
                continue;
            }
            if(scoreValue <= 70 && scoreValue >= 60){
                numberList.set(1, numberList.get(1)+1);
                continue;
            }
            if(scoreValue <= 80 && scoreValue > 70){
                numberList.set(2, numberList.get(2)+1);
                continue;
            }
            if(scoreValue <= 90 && scoreValue > 80){
                numberList.set(3, numberList.get(3)+1);
                continue;
            }
            if(scoreValue <= 100 && scoreValue > 90){
                numberList.set(4, numberList.get(4)+1);
                continue;
            }
        }
        Map<String, Object> retMap = new HashMap<String, Object>();
        retMap.put("courseName", courseName);
        retMap.put("numberList", numberList);
        retMap.put("rangeList", rangeStringList);
        retMap.put("type", "success");
        return retMap;
    }

}
