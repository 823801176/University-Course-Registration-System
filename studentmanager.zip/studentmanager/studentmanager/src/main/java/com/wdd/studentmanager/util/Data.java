package com.wdd.studentmanager.util;

import java.util.List;

public class Data {
    private List<Integer> ids ;

    public List<Integer> getIds() {
        return ids;
    }

    public void setIds(List<Integer> ids) {
        this.ids = ids;
    }
}
