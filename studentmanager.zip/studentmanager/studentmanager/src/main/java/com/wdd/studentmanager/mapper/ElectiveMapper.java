package com.wdd.studentmanager.mapper;

import com.wdd.studentmanager.domain.SelectedCourse;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @Classname ElectiveMapper
 * @Description None
 */
public interface ElectiveMapper {

    Integer selectByStuAndCourseId(@Param("studentid")Integer studentid, @Param("courseid")Integer courseid);
    Integer selectByStu(Integer studentid);

}
