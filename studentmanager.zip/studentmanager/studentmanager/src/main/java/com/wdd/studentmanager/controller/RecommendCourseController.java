package com.wdd.studentmanager.controller;

import com.wdd.studentmanager.domain.*;
import com.wdd.studentmanager.mapper.SelectedCourseMapper;
import com.wdd.studentmanager.service.*;
import com.wdd.studentmanager.util.AjaxResult;
import com.wdd.studentmanager.util.Const;
import com.wdd.studentmanager.util.PageBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.*;

/**
 * @Classname RecommendCourseController
 * @Description Course recommendation
 */
@Controller
@RequestMapping("/recommendCourse")
public class RecommendCourseController {


    //get student id
    @Autowired
    private StudentService studentService;

    //get course id
    @Autowired
    private CourseService courseService;

    //get elective
    @Autowired
    private ElectiveService electiveService;

    @Autowired
    private RecommendCourseService recommendService;



    @GetMapping("/recommendCourse_list")
    public String recommendCourseList(){
        return "recommend/recommendList";
    }

    /**
     * Use course id to check student registration information
     * @param studentid
     * @param session
     * @return
     */
    @RequestMapping("/getStudentRecommendCourseList")
    @ResponseBody
    public Object getStudentRecommendCourseList(@RequestParam(value = "studentid", defaultValue = "0")String studentid , HttpSession session){

        Student student = (Student) session.getAttribute(Const.STUDENT);
        Integer currentStudent=student.getId();

        //Get all students
        List<Student> selectAllStudent = studentService.selectAllStudent();


        List<Object> resultIds=new ArrayList<Object>();

        //Get all courses
        //Depends on student id and course id to get the score
        if(selectAllStudent.size()!=0) {
            Map<Integer,List<CourtsGoal>> goalMap = new HashMap<Integer, List<CourtsGoal>>();
            List<Integer> stuList = new ArrayList<Integer>();
            List<Course> selectAllCourse = (List<Course>) courseService.selectAllCourse();

            for(Student stu:selectAllStudent) {

                List<CourtsGoal> courtsGoals = new ArrayList<CourtsGoal>();
                Integer stucheck = electiveService.selectByStu(stu.getId());
                if(stucheck==null){
                    continue ;
                }

                for(Course cou:selectAllCourse) {
                    CourtsGoal courtsGoal = new CourtsGoal();
                    Integer goal = electiveService.selectByStuAndCourseId(stu.getId(), cou.getId());
                    if(goal==null){
                        continue ;
                    }
                    courtsGoal.setCourseId(cou.getId());
                    courtsGoal.setGoal(goal);
                    courtsGoals.add(courtsGoal);

                }

                goalMap.put(stu.getId(), courtsGoals);
                stuList.add(stu.getId());
            }
            System.out.println(goalMap);
            System.out.println(stuList);
            //System.out.println(selectAllCourse);
            //calculate the similarity of users
            Map<Integer,List<List<Object>>> dataMap = calcUserSimilarity(stuList.toArray(),goalMap);
            //Calculate the recommenation of courses
            Map<Integer, List<Object>> recommendCourse = calcRecommendCourse(dataMap,goalMap);

            resultIds=recommendCourse.get(currentStudent);
            System.out.print("result--courseId->:");
            System.out.println(resultIds);
            //handleRecommendCourse
            Map<Integer, List<Object>> handleRecommendCourse = handleRecommendCourse(recommendCourse,goalMap);

            //saveRecommendCourse
            //saveRecommendCourse(handleRecommendCourse);

        }else {
            System.out.println("none-recommend");
        }
        Map<Object,Object> paramMap = new HashMap();
        paramMap.put("ids",resultIds);
        List<Course> courseList = courseService.getCourseById(paramMap);

        return courseList;



    }


    public static Map<String, Object> removeMapKey(Map param) {
        Set set = param.keySet();

        for (Iterator iterator = set.iterator(); iterator.hasNext(); ) {
            Object obj = (Object) iterator.next();
            Object value = (Object) param.get(obj);
            if (value == null || value.equals("") || value.equals("null") || obj.toString().length() == 0) {
                iterator.remove();
            }
        }

        return param;
    }





    private static Map<Integer, List<Object>> handleRecommendCourse(Map<Integer, List<Object>> recommendCourse,Map<Integer,List<CourtsGoal>> goalMap) {
        Map<Integer, List<Object>> handleRecommendCourse = new HashMap<Integer, List<Object>>();

        for(Map.Entry<Integer,List<Object>> reco:recommendCourse.entrySet()) {
            //Get the recommended course
            List<Object> re_l = reco.getValue();
            List<Object> handleCourse = new ArrayList<Object>();
            for(Object obj:re_l) {
                List<CourtsGoal> list = goalMap.get(reco.getKey());
                for(CourtsGoal c_goal:list) {
                    if(Integer.parseInt(obj.toString())==c_goal.getCourseId()) {
                        if(c_goal.getGoal()==0) {
                            handleCourse.add(c_goal.getCourseId());
                        }
                    }
                }
            }
            handleRecommendCourse.put(reco.getKey(), handleCourse);
        }
        return handleRecommendCourse;
    }
    /*
     * Calculate similarity of students
     * Return the top 2 similar students
     */
    public static Map<Integer,List<List<Object>>> calcUserSimilarity(Object[] stuArr_p,Map<Integer,List<CourtsGoal>> goalMap_p) {
        //similarityUsers=new ArrayList();
        //get the similarity between target user and other users
        //Similarity user set
        Map<Integer,List<List<Object>>> dataMap = new HashMap<Integer, List<List<Object>>>();
        for(Object stu:stuArr_p) {
            //get 2 similar users
            List<List<Object>> similarityUsers= new ArrayList();
            List<List<Object>> userSimilaritys=new ArrayList<List<Object>>();
            //Iterate over alMap_p
            for(Map.Entry<Integer,List<CourtsGoal>> goal:goalMap_p.entrySet()) {
                //If student is the same, skip
                if(stu.toString().equals(goal.getKey().toString())) {
                    continue;
                }
                List<Object> userSimilarity=new ArrayList<Object>();
                //record the user id
                userSimilarity.add(goal.getKey());
                userSimilarity.add(calcTwoUserSimilarity(goal.getValue(),goalMap_p.get((Integer)stu)));
                userSimilaritys.add(userSimilarity);
            }
            sortCollection(userSimilaritys);

            System.out.println("The simularity with"+stu+"is: "+userSimilaritys);
            similarityUsers.add(userSimilaritys.get(0));
            similarityUsers.add(userSimilaritys.get(1));
            dataMap.put((Integer)stu, similarityUsers);
        }
        System.out.println(dataMap);
        //Show the similarity of target users and other 2 users
        return dataMap;
    }

    /**
     * Get course list, calculate the recommended course
     */
    private static Map<Integer,List<Object>> calcRecommendCourse(Map<Integer,List<List<Object>>> dataMap,Map<Integer,List<CourtsGoal>> goalMap){
        Map<Integer,List<List<Object>>> cf_map =  new HashMap<Integer, List<List<Object>>>();
        //Store the total recommended score for no course
        Map<Integer,Double> cf_sumRate =  new HashMap<Integer, Double>();
        //Go through the dataMap and pick up the courses recommended by different students
        for(Map.Entry<Integer,List<List<Object>>> data:dataMap.entrySet()) {
            double recommdRate=0,sumRate=0;
            //Get first similar user's value
            double xs_1 = Double.parseDouble(data.getValue().get(0).get(1).toString());
            //Get second similar user's value
            double xs_2 = Double.parseDouble(data.getValue().get(1).get(1).toString());
            List<CourtsGoal> list_1 = goalMap.get(data.getValue().get(0).get(0));
            List<CourtsGoal> list_2 = goalMap.get(data.getValue().get(1).get(0));
            if(list_1.size()==list_2.size()) {
                List<List<Object>> recommendCourts = new ArrayList<List<Object>>();
                for(int i=0;i<list_1.size();i++) {
                    List<Object>  recommendCourt=new ArrayList();
                    recommdRate = list_1.get(i).getGoal() * xs_1 + list_2.get(i).getGoal() * xs_2;
                    //Add course
                    recommendCourt.add(list_1.get(i).getCourseId());
                    //Add recommended score
                    recommendCourt.add(recommdRate);
                    //print the recommended course, user and score
                    System.err.println("User "+data.getKey()+"course"+list_1.get(i)+" :"+recommdRate);
                    recommendCourts.add(recommendCourt);
                    sumRate+=recommdRate;
                }
                cf_map.put(data.getKey(), recommendCourts);
                cf_sumRate.put(data.getKey(), sumRate);
            }
            for(CourtsGoal cGoal:list_1) {
            System.out.println("To user "+data.getKey()+" Recommand by user: "+data.getValue().get(0).get(0)+" The simility value is: "+data.getValue().get(0).get(1)+" Course information: "+cGoal.getCourseId()+" Value: "+cGoal.getGoal());
            }
        }
        System.err.println(cf_map);
        System.out.println(cf_sumRate);
        //The current collection holds the collection of courses recommended for key
        Map<Integer,List<Object>> target_map = new HashMap<Integer, List<Object>>();
        for(Map.Entry<Integer,List<List<Object>>> cf_d:cf_map.entrySet()) {
            List<Object> targetRecommendCourts = new ArrayList<Object>();
            for(List<Object> obj:cf_d.getValue()) {
                if(Double.parseDouble(obj.get(1).toString()) > cf_sumRate.get(cf_d.getKey())/cf_d.getValue().size()){ //Items with higher than average recommendation are likely to be recommended
                    targetRecommendCourts.add(obj.get(0));
                }
            }
            target_map.put(cf_d.getKey(), targetRecommendCourts);
        }
        return target_map;
    }

    /**
     * Calculate user similarity (Euclidean distance) based on user data
     * @param user1Stars  Other users rate the score
     * @param user2Starts  Current user rating score
     * @return
     */
    private static double calcTwoUserSimilarity(List<CourtsGoal> user1Stars,List<CourtsGoal> user2Starts){
        float sum=0;
        for(int i=0;i<user1Stars.size();i++){
            sum+=Math.pow(user1Stars.get(i).getGoal()-user2Starts.get(i).getGoal(),2);//平方
        }
        return Math.sqrt(sum);//sqrt
    }

    /**
     * Sorting of sets
     * @param list
     */
    private static void sortCollection(List<List<Object>> list){
        Collections.sort(list, new Comparator<List<Object>>() {
            @Override
            public int compare(List<Object> o1, List<Object> o2) {
                if(Double.valueOf(o1.get(1).toString()) > Double.valueOf(o2.get(1).toString())){
                    return 1;
                }else if(Double.valueOf(o1.get(1).toString()) < Double.valueOf(o2.get(1).toString())){
                    return -1;
                }else{
                    return 0;
                }
            }
        });
    }



}
