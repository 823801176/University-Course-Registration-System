package com.wdd.studentmanager.util;

import java.io.File;

/**
 * @Classname UploadUtil
 * @Description None
 */
public class UploadUtil {
    // Directory at the root of the project - SpringBoot static directory is equivalent to the root (SpringBoot default)
    public final static String IMG_PATH_PREFIX = "static/upload/imgs";

    public static File getImgDirFile(){

        // Build a "folder" path for the uploaded files
        String fileDirPath = new String("src/main/resources/" + IMG_PATH_PREFIX);

        File fileDir = new File(fileDirPath);
        if(!fileDir.exists()){
            // Generate folders recursively
            fileDir.mkdirs();
        }
        return fileDir;
    }
}
