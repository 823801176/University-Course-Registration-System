package com.wdd.studentmanager.service.Impl;

import com.wdd.studentmanager.domain.SelectedCourse;
import com.wdd.studentmanager.mapper.CourseMapper;
import com.wdd.studentmanager.mapper.SelectedCourseMapper;
import com.wdd.studentmanager.service.RecommendCourseService;
import com.wdd.studentmanager.util.PageBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Map;

/**
 * @Classname RecommendCourseServiceImpl
 * @Description None
 */
@Service
public class RecommendCourseServiceImpl implements RecommendCourseService {

    @Override
    public void startRecommend(){
        MyCFRecomment my= new MyCFRecomment();
        my.recommend();

    }




}
