package com.wdd.studentmanager.service;

import com.wdd.studentmanager.domain.Course;
import com.wdd.studentmanager.util.PageBean;

import java.util.List;
import java.util.Map;

/**
 * @Classname CourseService
 * @Description None
 */
public interface CourseService {
    PageBean<Course> queryPage(Map<String, Object> paramMap);

    int addCourse(Course course);

    int editCourse(Course course);

    int deleteCourse(List<Integer> ids);

    List<Course> getCourseById(Map<Object, Object> paramMap);

    List<Course> selectAllCourse();

    int findByName(String name);
}
