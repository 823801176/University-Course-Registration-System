package com.wdd.studentmanager.domain;

/**
 * @Classname CourtsGoal
 * @Description Court Goals
 */
 
public class CourtsGoal {
    private Integer id;
    private Integer studentId;
    private Integer courseId;
    private Integer goal;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public Integer getGoal() {
        return goal;
    }

    public void setGoal(Integer goal) {
        this.goal = goal;
    }
}
