package com.wdd.studentmanager;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @Classname IteratorTest
 * @Description None
 * @Date 2019/6/30 19:50
 * @Created by WDD
 */
public class IteratorTest {
    @Test
    public void test(){
        //set data
        List<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(3);

        //Male only
        Iterator<Integer> iterator = list.iterator();
        while (iterator.hasNext()) {

            if (iterator.next().equals(3)) {
                iterator.remove();
            }
        }
        System.out.println(list.size());
    }
}
